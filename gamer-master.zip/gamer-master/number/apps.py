from django.apps import AppConfig


class NumberConfig(AppConfig):
    name = 'number'
